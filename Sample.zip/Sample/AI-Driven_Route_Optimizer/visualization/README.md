# Interactive Visualization
### using Streamlit, Mapbox and PyDeck

First install Streamlit using `pip install streamlit`.

Then change to the current directory containing `main.py` and run using `streamlit run main.py` :)
